#include <reg51.h>
#include "io.h"


sbit READ = P3^2; /* Define these according to how you have connected the */
sbit WRITE = P3^3;/* RD, WR, and INTR pins                                */ 
sbit INTR = P3^4;


void main( void ) {

	unsigned char adVal;
	unsigned long volts;
	InitIO();

	READ = 1;
	WRITE = 1;
	INTR = 1;
	ClearScreen();

        while(1) {

               /* Make a low-to-high transition on the WR input */

               while( INTR == 1 );    /* wait until the INTR signal makes  */
                                      /* high-to-low transition indicating */
                                      /* completion of conversion          */

                         
                /* Read the voltage value from the port */              
                READ = 0;
                adVal = P1;
                READ = 1;

                /* Compute the digital value of the volatge read */

                /* Print the value of the voltage in decimal form */
	}
}