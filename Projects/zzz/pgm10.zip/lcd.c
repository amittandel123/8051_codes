
/* Sample Software to display a message on a 16 x2 character LCD module
/* from a parallel port of a PC
#include <time.h>
#include <conio.h>
#include <string.h>
#define PORTADDRESS 0x378 /*Enter port address here */
#define DATA PORTADDRESS+0 /*LCD data port */
#define CONTROL PORTADDRESS+2 /*LCD control port */
void main (void)
{
/* Total of 40 characters including spaces in each line of string */
char string[] = {�>>8051projects<< �
�ABC abc 123,!@$? �};
char init[10];
int count;
int len;
init[0] = 0x0F; /* Initialize display */
init[1] = 0x01; /* Clear display */
init[2] = 0x38; /* Dual line 8 bits */
_out(CONTROL, _inp(CONTROL) & 0xDF); /* Reset control port */
_out(CONTROL, _inp(CONTROL) | 0x08); /*Set RS */
/* Initialization routine */
for (count = 0; count <= 2; count++)
{
_out(DATA, init[count]);
_out(CONTROL,_inp(CONTROL) | 0x01; /*Set Enable */
delay(20);
_out(CONTROL,_inp(CONTROL) & 0xFE; /*Reset Enable */
delay(20);
}
_out(CONTROL, _inp(CONTROL) & 0xF7);/*Reset RS */
/* Output the message */
len = strlen(string);
for (count = 0; count < len; count++)
{
_out(DATA, string[count]);
_out(CONTROL,_inp(CONTROL) | 0x01; /*Set Enable */
delay(2);
_out(CONTROL,_inp(CONTROL) & 0xFE); /*Reset Enable */
delay(2);
}
}