// Header File for <Display_utils.c> 

unsigned short mask(unsigned short num);
